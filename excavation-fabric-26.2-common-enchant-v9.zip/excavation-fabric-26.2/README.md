# Excavation Fabric Mod for Minecraft 26.2

Adds the `Excavation` enchantment for pickaxes and shovels.

When a player breaks a block with an enchanted pickaxe or shovel, the mod also
breaks nearby blocks in a 3x3x3 cube around the original block.

## Files

- `src/main/java/com/joshua/excavation/ExcavationMod.java` - event hook and mining logic
- `src/main/resources/data/excavation/enchantment/excavation.json` - data-driven enchantment
- `src/main/resources/data/excavation/tags/item/excavation_tools.json` - pickaxe/shovel enchantment target
- `src/main/resources/data/minecraft/tags/enchantment/non_treasure.json` - adds Excavation to normal enchanting-table rolls
- `src/main/resources/assets/excavation/lang/en_us.json` - enchantment name

## Build

Use Java 25.

```bash
./gradlew build
```

The jar will be in:

```text
build/libs/
```

## Notes

The version values in `gradle.properties` may need to be changed to match the
exact Fabric API builds published for Minecraft 26.2.

This project uses the Fabric Loom plugin id shown in current 26.2 templates:

```gradle
id "net.fabricmc.fabric-loom" version "1.17-SNAPSHOT"
```

This project builds against the stable Minecraft development artifact:

```properties
minecraft_version=26.2
```
